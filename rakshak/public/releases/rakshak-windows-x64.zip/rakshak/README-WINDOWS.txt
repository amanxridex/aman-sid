===============================================================
RAKSHAK ZERO-TRUST PERIMETER MATRIX — WINDOWS x64 EDITION (v2.4.1)
===============================================================

Commercial Production License // Anti-AI Scraping & Crawler Defense
Native Windows PE 64-bit Workstation Shield Engine

1. Quick Start:
   Run RakshakShield.exe directly from this folder, or add bin/ to User PATH.

2. Native Shield Commands (RakshakShield.exe):
   RakshakShield.exe status                  - Real-time kernel & folder guard status
   RakshakShield.exe test                    - Run sub-0.02ms latency & telemetry verification
   RakshakShield.exe compile defense.rsk     - Compile .rsk policy into .rskb binary bytecode
   RakshakShield.exe disassemble defense.rskb- Disassemble bytecode instructions
   RakshakShield.exe watch C:\path\to\dir    - Zero-trust real-time file monitoring
   RakshakShield.exe honeypot                - Deploy HMAC-signed adversarial honeytoken decoy
   RakshakShield.exe daemon                  - Continuous background isolation sentinel

3. Universal CLI Commands (rakshak):
   rakshak init              - Initialize perimeter policy
   rakshak status            - Workstation shield status
   rskc compile defense.rsk  - Universal RSK compiler
   rakshak dump defense.rskb - Disassemble bytecode

4. Background Protection:
   Run service\RakshakService.cmd to start the background agent.
