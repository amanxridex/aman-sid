===============================================================
RAKSHAK ZERO-TRUST PERIMETER MATRIX — LINUX x64 (v1.0.0)
===============================================================

Commercial Production License // Debian, Ubuntu, Fedora, Arch, RHEL

1. Setup:
   curl -fsSL https://rakshakus.vercel.app/install.sh | bash

2. Commands:
   rakshak init              - Initialize perimeter policy
   rakshak status            - Real-time kernel & process status
   rskc compile defense.rsk  - Compile .rsk policy to .rskb binary bytecode
   rakshak dump defense.rskb - Disassemble bytecode instructions

3. Systemd Service:
   sudo cp systemd/rakshak.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable --now rakshak
