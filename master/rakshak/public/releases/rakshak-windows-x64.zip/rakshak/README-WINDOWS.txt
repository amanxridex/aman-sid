===============================================================
RAKSHAK ZERO-TRUST PERIMETER MATRIX — WINDOWS x64 EDITION (v2.4.1)
===============================================================

Commercial Production License // Anti-AI Scraping & Crawler Defense
Native Windows PE 64-bit Workstation Shield Engine

1. Quick Start:
   Double-click RakshakShield.exe to open the Cyber-Defense Command Center.
   The active Green Shield immediately protects your system in the notification area.

2. Native Shield Commands (RakshakShield.exe):
   RakshakShield.exe gui                     - Interactive Cyber-Defense Command Center
   RakshakShield.exe tray                    - Run minimized in taskbar with active green indicator
   RakshakShield.exe install                 - Register in Windows Startup & Add/Remove Programs
   RakshakShield.exe uninstall [--quiet]     - 1-Click clean uninstallation (zero questions/residual)
   RakshakShield.exe status                  - Real-time kernel & folder guard status
   RakshakShield.exe scan                    - Deep threat scan for rogue AI scrapers & OCR
   RakshakShield.exe kill <PID>              - Terminate rogue scraping process
   RakshakShield.exe protect-window          - Enforce WDA_EXCLUDE (anti-Recall & anti-OCR)
   RakshakShield.exe compile defense.rsk     - Compile .rsk policy into .rskb binary bytecode
   RakshakShield.exe disassemble defense.rskb- Disassemble bytecode instructions
   RakshakShield.exe watch C:\path\to\dir    - Zero-trust real-time file monitoring
   RakshakShield.exe honeypot                - Deploy HMAC-signed adversarial honeytoken decoy
   RakshakShield.exe daemon                  - Continuous background isolation sentinel

3. Universal CLI Commands (rakshak):
   rakshak init              - Initialize perimeter policy
   rakshak status            - Workstation shield status
   rskc compile defense.rsk  - Universal RSK compiler
   rakshak dump defense.rskb - Disassemble bytecode

4. 1-Click Uninstall:
   Settings > Installed Apps > Rakshak Workstation Defense Shield > Uninstall
   or right-click Green Shield in system tray > "1-Click Clean Uninstall"
