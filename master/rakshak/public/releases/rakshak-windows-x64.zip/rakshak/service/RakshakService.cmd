@echo off
REM Rakshak Windows Background Service Controller
echo Starting Rakshak Perimeter Defense on Windows...
"%~dp0\..\bin\RakshakShield.exe" tray
