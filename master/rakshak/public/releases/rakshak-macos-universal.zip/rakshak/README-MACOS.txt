===============================================================
RAKSHAK ZERO-TRUST PERIMETER MATRIX — macOS UNIVERSAL (v1.0.0)
===============================================================

Commercial Production License // Apple Silicon (M1-M4) & Intel x86_64

1. Setup:
   Add bin/ to your ~/.zshrc or run:
   curl -fsSL https://rakshakus.vercel.app/install.sh | bash

2. Commands:
   rakshak init              - Initialize perimeter policy
   rakshak status            - Real-time kernel & process status
   rskc compile defense.rsk  - Compile .rsk policy to .rskb binary bytecode
   rakshak dump defense.rskb - Disassemble bytecode instructions

3. macOS LaunchAgent:
   cp launchd/com.rakshak.daemon.plist ~/Library/LaunchAgents/
   launchctl load ~/Library/LaunchAgents/com.rakshak.daemon.plist
